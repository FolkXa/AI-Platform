(()=>{var e={};e.id=949,e.ids=[949],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},60273:(e,t,a)=>{"use strict";a.r(t),a.d(t,{patchFetch:()=>m,routeModule:()=>l,serverHooks:()=>g,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>h});var s={};a.r(s),a.d(s,{POST:()=>p,maxDuration:()=>d});var r=a(15342),n=a(14151),i=a(39358),o=a(35673),u=a(91059);let d=30;async function p(e){let{messages:t,sessionId:a,file:s}=await e.json();return a&&s?new Response("CSV chat should use the backend service directly",{status:400}):(0,u.gM)({model:(0,o.N)("gpt-4o"),system:`You are a data analysis assistant that helps users understand and analyze their data through natural language queries.

Key capabilities:
- Answer questions about data trends, patterns, and insights
- Perform calculations and statistical analysis
- Generate data visualizations descriptions
- Provide business intelligence insights
- Help with data interpretation and recommendations

Sample data context: Sales data with columns for Date, Product, Category, Sales, Quantity, Region, Customer_Type, Revenue.

When answering questions:
1. Provide specific, actionable insights
2. Use data-driven language
3. Suggest follow-up questions or analysis
4. Format numbers clearly (e.g., $2.4M, 1,250 units)
5. Reference specific data points when possible`,messages:t}).toDataStreamResponse()}let l=new r.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/data-chat/route",pathname:"/api/data-chat",filename:"route",bundlePath:"app/api/data-chat/route"},resolvedPagePath:"/Users/jirakit.c/Documents/learn/ai-platform/web/app/api/data-chat/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:c,workUnitAsyncStorage:h,serverHooks:g}=l;function m(){return(0,i.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:h})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78492:()=>{},88220:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[358,60],()=>a(60273));module.exports=s})();